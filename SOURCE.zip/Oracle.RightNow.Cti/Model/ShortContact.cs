﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oracle.RightNow.Cti.Model
{
	public class ShortContact
	{
		public long ContactID { get; set; }
		public string Username { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string FullName
		{
			get
			{
				return $"{FirstName} {LastName}";
			}
		}
		public string Email { get; set; }
		public string AddressStreet { get; set; }
		public string AddressCity { get; set; }
		public string AddressState { get; set; }
		public string AddressCountry { get; set; }
		public string FullAddress
		{
			get
			{
				List<string> addressBuffer = new List<string>();

				if (!string.IsNullOrEmpty(AddressStreet))
				{
					addressBuffer.Add(AddressStreet);
				}


				if (!string.IsNullOrEmpty(AddressCity))
				{
					addressBuffer.Add(AddressCity);
				}


				if (!string.IsNullOrEmpty(AddressState))
				{
					addressBuffer.Add(AddressState);
				}


				if (!string.IsNullOrEmpty(AddressCountry))
				{
					addressBuffer.Add(AddressCountry);
				}

				return String.Join(", ", addressBuffer.ToArray());
			}
		}
	}
}
