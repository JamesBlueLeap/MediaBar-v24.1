﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Oracle.RightNow.Cti.MediaBar.Views;
using System.Text.RegularExpressions;

namespace Oracle.RightNow.Cti.MediaBar.Views {
    /// <summary>
    
    public partial class TransferDialog : Window {
        public TransferDialog() {
            InitializeComponent();
            FocusManager.SetFocusedElement(this, cbTargetNumber);
        }
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9,+]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
