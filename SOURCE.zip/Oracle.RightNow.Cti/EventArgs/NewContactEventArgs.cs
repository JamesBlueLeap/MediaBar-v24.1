﻿using System;

namespace Oracle.RightNow.Cti
{
    public class NewContactEventArgs : EventArgs
	{
        public NewContactEventArgs(long contactID)
		{
			this.ContactID = contactID;
        }

        public long ContactID { get; set; }
    }
}